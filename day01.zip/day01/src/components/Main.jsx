const Main = () => {
    const number = 10;

    return(
        <main>
            <h1>main</h1>
            <h2>{number % 2 === 0 ? "짝" : "홀"}</h2>
        </main>

    );
}

export default Main;