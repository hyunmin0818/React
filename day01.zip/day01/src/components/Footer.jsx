const Footer = () => {
    return(
      <Footer>
          <h1>Footer</h1>
      </Footer>

    );

}

export default Footer;